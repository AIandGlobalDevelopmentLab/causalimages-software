# tfruns 1.5.3

* Updates for R-devel (4.4)

# tfruns 1.5.2

* Added support for dark mode in the keras metrics viewer.

# tfruns 1.5.1

* Updated Rd docs for compatibility with R-4.2 / HTML5

# tfruns 1.5.0

# tfruns 1.4.0.9000

* Added a `NEWS.md` file to track changes to the package. (#56)
* Added GitHub actions CI and removed Travis. (#54)
* Fixed issue with precision of serialized metrics and flags. (#55)
