//# {{
#ifdef __INTELLISENSE__
#include "preprocessor.h"
#endif
//# }}
TOML_PUSH_WARNINGS;
#ifdef _MSC_VER
#pragma inline_recursion(on)
#pragma push_macro("min")
#pragma push_macro("max")
#undef min
#undef max
#endif
