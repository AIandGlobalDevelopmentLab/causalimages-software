

std::map<double, size_t> table(std::vector<double> &v);
std::map<double, size_t> combine_tables(std::map<double, size_t> &x, std::map<double, size_t> &y);
std::vector<double> table2vector(std::map<double, size_t> &x);
std::vector<std::vector<double>> table2vector2(std::map<double, size_t> &x);
