#pragma once

struct InternalParams
{
    static double sml;
    static double eps;
    static double big;
    static int mnlam;
    static double rsqmax;
    static double pmin;
    static double exmx;
    static int itrace;
    static double bnorm_thr;
    static int bnorm_mxit;
    static double epsnr;
    static int mxitnr;
};
