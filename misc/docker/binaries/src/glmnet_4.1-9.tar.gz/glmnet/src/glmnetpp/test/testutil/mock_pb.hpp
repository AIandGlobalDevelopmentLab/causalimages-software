#pragma once

namespace glmnetpp {

// TODO: this may change in the future.
// Mock progress bar since our tests don't need to test this behavior.
inline void mock_setpb(int) {}

} // namespace glmnetpp
