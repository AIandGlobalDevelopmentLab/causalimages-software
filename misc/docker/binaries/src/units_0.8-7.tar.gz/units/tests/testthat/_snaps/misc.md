# str works

    Code
      str(set_units(1 / 1:3, m / s))
    Output
       Units: [m/s] num [1:3] 1 0.5 0.333

