## source R-script at inst/unit_tests/unit_test_rapply.R
source(system.file("unit_tests", "unit_test_rrapply.R", package = "rrapply"), local = TRUE)
