lines.survexp <- function(x, type="l", ...) {
    type <- type
    NextMethod("lines", type=type, ...)
}

